# kapsel-plugin-inappbrowser

Fork of the Apache InAppBrowser Plugin.
