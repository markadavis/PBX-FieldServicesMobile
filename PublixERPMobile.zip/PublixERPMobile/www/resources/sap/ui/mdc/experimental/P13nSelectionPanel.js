/*
 * ! SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2017 SAP SE. All rights reserved
 */
sap.ui.define(['jquery.sap.global','./P13nPanel'],function(q,P){"use strict";var a=P.extend("sap.ui.mdc.experimental.P13nSelectionPanel",{metadata:{library:"sap.ui.mdc"}});return a;},true);
