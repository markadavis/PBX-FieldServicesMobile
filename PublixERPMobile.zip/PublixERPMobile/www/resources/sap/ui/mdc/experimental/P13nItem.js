/*
 * ! SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2017 SAP SE. All rights reserved
 */
sap.ui.define(['sap/ui/core/Element'],function(E){"use strict";var P=E.extend("sap.ui.mdc.experimental.P13nItem",{metadata:{"abstract":true,library:"sap.ui.mdc",properties:{columnKey:{type:"string",defaultValue:undefined},text:{type:"string",defaultValue:undefined},tooltip:{type:"string",defaultValue:undefined}}}});return P;},true);
