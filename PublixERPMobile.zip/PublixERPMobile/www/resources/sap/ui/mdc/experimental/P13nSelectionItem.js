/*
 * ! SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2017 SAP SE. All rights reserved
 */
sap.ui.define(['sap/ui/mdc/experimental/P13nItem'],function(P){"use strict";var a=P.extend("sap.ui.mdc.experimental.P13nSelectionItem",{metadata:{library:"sap.ui.mdc",properties:{selected:{type:"boolean",defaultValue:false},position:{type:"int"},href:{type:"string",defaultValue:undefined},target:{type:"string",defaultValue:undefined},press:{type:"object",defaultValue:null}}}});return a;},true);
