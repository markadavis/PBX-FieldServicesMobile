/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2017 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['./Item','./library'],function(I,l){"use strict";var S=I.extend("sap.ui.core.SeparatorItem",{metadata:{library:"sap.ui.core"}});return S;});
